export default function Page() {
  return <div>Payroll</div>;
}