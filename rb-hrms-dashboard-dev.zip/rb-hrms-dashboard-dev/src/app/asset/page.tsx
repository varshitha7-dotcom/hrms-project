export default function Page() {
  return <div>Asset Management Page</div>;
}