export default function Page() {
  return <div>Onboarding Management Page</div>;
}