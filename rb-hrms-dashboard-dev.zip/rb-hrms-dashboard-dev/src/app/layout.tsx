'use client'

import "./globals.css";
import { ThemeProvider } from "@/components/theme-provider";
import { LayoutProvider } from "@/components/layout-context";
import Sidebar from "@/components/sidebar";
import Topbar from "@/components/topbar";
import { Inter } from "next/font/google";
import { usePathname } from "next/navigation";

const inter = Inter({ subsets: ["latin"] });

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const isAuthPage = pathname.startsWith('/auth');

  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider>
          <LayoutProvider>
            {isAuthPage ? (
              <main className="min-h-screen">
                {children}
              </main>
            ) : (
              <div className="flex h-screen">
                <Sidebar />
                <div className="flex flex-col flex-1">
                  <Topbar />
                  <main className="p-6 flex-1 overflow-y-auto">
                    {children}
                  </main>
                </div>
              </div>
            )}
          </LayoutProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}