export default function Page() {
  return <div>Learning and dev Page</div>;
}