export default function DashboardPage() {
  return (
    <div className="card p-6">
      Dashboard Content
    </div>
  );
}
