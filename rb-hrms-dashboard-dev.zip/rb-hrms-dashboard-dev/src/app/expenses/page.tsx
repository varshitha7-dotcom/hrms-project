export default function Page() {
  return <div>Expense Management Page</div>;
}