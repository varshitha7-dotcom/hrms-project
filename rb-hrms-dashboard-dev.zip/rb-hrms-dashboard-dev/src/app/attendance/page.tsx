export default function Page() {
  return <div>Attendance and leave Management Page</div>;
}