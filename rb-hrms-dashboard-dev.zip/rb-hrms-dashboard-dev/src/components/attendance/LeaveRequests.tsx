"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

export default function Page() {
  const [name, setName] = useState("");
  const [reason, setReason] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // Fetch data
  const fetchRequests = async () => {
    const { data, error } = await supabase
      .from("leave_requests")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Fetch error:", error);
    } else {
      setRequests(data || []);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  // ✅ SUBMIT (WITH POPUP)
  const handleSubmit = async () => {
    if (!name || !reason || !fromDate || !toDate) {
      alert("❌ Please fill all fields");
      return;
    }

    setLoading(true);

    const { error } = await supabase.from("leave_requests").insert([
      {
        employee_name: name,
        reason,
        from_date: fromDate,
        to_date: toDate,
      },
    ]);

    if (error) {
      console.error("Insert error:", error);
      alert("❌ Failed to send leave request");
    } else {
      alert("✅ Leave request sent successfully!"); // 🔥 POPUP

      setName("");
      setReason("");
      setFromDate("");
      setToDate("");

      fetchRequests();
    }

    setLoading(false);
  };

  // Approve / Reject
  const updateStatus = async (id: string, status: string) => {
    const { error } = await supabase
      .from("leave_requests")
      .update({ status })
      .eq("id", id);

    if (error) console.error("Update error:", error);

    fetchRequests();
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">

      {/* 🔵 Title */}
      <h1 className="text-2xl font-bold text-blue-600 mb-6 animate-pulse">
        Leave Request Management
      </h1>

      {/* 🧾 FORM */}
      <div className="bg-white p-6 rounded-xl shadow-md max-w-md mb-6 hover:scale-105 transition">

        <h2 className="text-lg font-semibold mb-4">Apply Leave</h2>

        <input
          className="w-full mb-3 p-2 border rounded focus:ring-2 focus:ring-blue-400"
          placeholder="Employee Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <input
          className="w-full mb-3 p-2 border rounded focus:ring-2 focus:ring-blue-400"
          placeholder="Reason"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
        />

        <input
          type="date"
          className="w-full mb-3 p-2 border rounded"
          value={fromDate}
          onChange={(e) => setFromDate(e.target.value)}
        />

        <input
          type="date"
          className="w-full mb-3 p-2 border rounded"
          value={toDate}
          onChange={(e) => setToDate(e.target.value)}
        />

        {/* 🔵 BUTTON */}
        <button
          onClick={handleSubmit}
          disabled={loading}
          className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition"
        >
          {loading ? "Submitting..." : "Submit Request"}
        </button>
      </div>

      {/* 📋 LIST */}
      <h2 className="text-xl font-semibold mb-4">All Requests</h2>

      {requests.length === 0 && (
        <p className="text-gray-500">No requests found</p>
      )}

      {requests.map((req) => (
        <div
          key={req.id}
          className="bg-white p-4 mb-3 rounded shadow flex justify-between"
        >
          <div>
            <p className="font-bold">{req.employee_name}</p>
            <p>{req.reason}</p>
            <p className="text-sm">{req.from_date} → {req.to_date}</p>
            <p className="text-sm">{req.status}</p>
          </div>

          {req.status === "pending" && (
            <div className="flex gap-2">
              <button
                onClick={() => updateStatus(req.id, "approved")}
                className="bg-green-500 text-white px-2 rounded"
              >
                Approve
              </button>
              <button
                onClick={() => updateStatus(req.id, "rejected")}
                className="bg-red-500 text-white px-2 rounded"
              >
                Reject
              </button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}