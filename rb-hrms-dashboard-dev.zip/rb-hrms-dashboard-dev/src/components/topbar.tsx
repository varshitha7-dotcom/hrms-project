"use client";

import { useTheme } from "next-themes";
import { useLayout } from "./layout-context";
import { Sun, Moon, Menu, Bell, Search } from "lucide-react";
import { useEffect, useState } from "react";



export default function Topbar() {
  const { theme, setTheme } = useTheme();
  const { collapsed, setCollapsed } = useLayout();
  const [mounted, setMounted] = useState(false);

useEffect(() => {
  setMounted(true);
}, []);

  return (
    <header className="h-18 border-b border-[var(--border)] flex items-center justify-between px-6">

      {/* LEFT */}
      <div className="flex items-center gap-4 w-full max-w-xl">

        {/* Sidebar toggle */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 rounded-lg border border-[var(--border)] hover-bg"
        >
          <Menu size={22} />
        </button>

        {/* Search bar */}
        <div className="flex items-center gap-2 w-full bg-[var(--card)] border border-[var(--border)] rounded-lg px-3 py-2">
          <Search size={22} className="text-[var(--muted)]" />
          <input
            type="text"
            placeholder="Search or type command..."
            className="w-full bg-transparent outline-none text-sm"
          />
          
        </div>
      </div>

      {/* RIGHT */}
      <div className="flex items-center gap-4">

        {/* Theme */}
        <button
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          className="p-2 rounded-full border border-[var(--border)] hover:bg-[var(--hover)]"
        >
          {mounted && (theme === "dark" ? <Sun size={22} /> : <Moon size={22} />)}
        </button>

        {/* Notification */}
        <button className="relative p-2 rounded-full border border-[var(--border)] hover-bg">
          <Bell size={22} />
          
        </button>

        {/* Profile */}
        <div className="flex items-center gap-2 cursor-pointer">
          <div className="w-8 h-8 rounded-full bg-blue-400" />
          <span className="text-sm font-medium">ADMIN</span>
        </div>

      </div>
    </header>
  );
}