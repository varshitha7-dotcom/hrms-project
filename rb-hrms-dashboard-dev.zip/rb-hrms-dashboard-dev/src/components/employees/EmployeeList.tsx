"use client";

import { useState, useMemo } from "react";
import BulkUpload from "@/components/employees/BulkUpload";
import Link from "next/link";
import {
  Plus,
  Search,
  Filter,
  Download,
  Edit,
  Trash2,
  ChevronLeft,
  ChevronRight,
  User,
  Building2,
  Briefcase,
  Calendar,
  Shield,
  MoreVertical,
} from "lucide-react";

// --- Types ---
type EmployeeStatus = "Active" | "Inactive" | "Probation";

interface Employee {
  id: string;
  employeeId: string;
  name: string;
  department: string;
  role: string;
  reportingManager: string;
  joiningDate: string;
  status: EmployeeStatus;
  email: string;
  phone: string;
}

// --- Dummy Data ---
const dummyEmployees: Employee[] = [
  {
    id: "1",
    employeeId: "EMP001",
    name: "Alice Johnson",
    department: "Engineering",
    role: "Senior Software Engineer",
    reportingManager: "John Smith",
    joiningDate: "2022-03-15",
    status: "Active",
    email: "alice.johnson@company.com",
    phone: "+1-555-0101",
  },
  {
    id: "2",
    employeeId: "EMP002",
    name: "Bob Williams",
    department: "HR",
    role: "HR Manager",
    reportingManager: "Jane Doe",
    joiningDate: "2021-07-22",
    status: "Active",
    email: "bob.williams@company.com",
    phone: "+1-555-0102",
  },
  {
    id: "3",
    employeeId: "EMP003",
    name: "Carol Davis",
    department: "Marketing",
    role: "Marketing Specialist",
    reportingManager: "Alice Johnson",
    joiningDate: "2023-01-10",
    status: "Probation",
    email: "carol.davis@company.com",
    phone: "+1-555-0103",
  },
  {
    id: "4",
    employeeId: "EMP004",
    name: "David Miller",
    department: "Finance",
    role: "Financial Analyst",
    reportingManager: "Bob Williams",
    joiningDate: "2022-09-05",
    status: "Active",
    email: "david.miller@company.com",
    phone: "+1-555-0104",
  },
  {
    id: "5",
    employeeId: "EMP005",
    name: "Eva Martinez",
    department: "Engineering",
    role: "DevOps Engineer",
    reportingManager: "John Smith",
    joiningDate: "2023-04-18",
    status: "Active",
    email: "eva.martinez@company.com",
    phone: "+1-555-0105",
  },
  {
    id: "6",
    employeeId: "EMP006",
    name: "Frank Lee",
    department: "Sales",
    role: "Sales Executive",
    reportingManager: "Jane Doe",
    joiningDate: "2021-11-30",
    status: "Inactive",
    email: "frank.lee@company.com",
    phone: "+1-555-0106",
  },
  {
    id: "7",
    employeeId: "EMP007",
    name: "Grace Kim",
    department: "Engineering",
    role: "Frontend Developer",
    reportingManager: "Alice Johnson",
    joiningDate: "2023-06-12",
    status: "Probation",
    email: "grace.kim@company.com",
    phone: "+1-555-0107",
  },
  {
    id: "8",
    employeeId: "EMP008",
    name: "Henry Wilson",
    department: "Operations",
    role: "Operations Manager",
    reportingManager: "Bob Williams",
    joiningDate: "2020-05-25",
    status: "Active",
    email: "henry.wilson@company.com",
    phone: "+1-555-0108",
  },
  {
    id: "9",
    employeeId: "EMP009",
    name: "Ivy Chen",
    department: "Customer Support",
    role: "Support Specialist",
    reportingManager: "Henry Wilson",
    joiningDate: "2022-12-01",
    status: "Active",
    email: "ivy.chen@company.com",
    phone: "+1-555-0109",
  },
  {
    id: "10",
    employeeId: "EMP010",
    name: "Jack Thompson",
    department: "Engineering",
    role: "Backend Developer",
    reportingManager: "Alice Johnson",
    joiningDate: "2023-08-20",
    status: "Active",
    email: "jack.thompson@company.com",
    phone: "+1-555-0110",
  },
  {
    id: "11",
    employeeId: "EMP011",
    name: "Karen Singh",
    department: "Legal",
    role: "Legal Counsel",
    reportingManager: "Jane Doe",
    joiningDate: "2021-04-14",
    status: "Active",
    email: "karen.singh@company.com",
    phone: "+1-555-0111",
  },
  {
    id: "12",
    employeeId: "EMP012",
    name: "Leo Brown",
    department: "Product",
    role: "Product Manager",
    reportingManager: "John Smith",
    joiningDate: "2022-10-30",
    status: "Active",
    email: "leo.brown@company.com",
    phone: "+1-555-0112",
  },
  {
    id: "13",
    employeeId: "EMP013",
    name: "Maya Patel",
    department: "QA",
    role: "QA Engineer",
    reportingManager: "Alice Johnson",
    joiningDate: "2023-03-22",
    status: "Probation",
    email: "maya.patel@company.com",
    phone: "+1-555-0113",
  },
  {
    id: "14",
    employeeId: "EMP014",
    name: "Noah Garcia",
    department: "Security",
    role: "Security Analyst",
    reportingManager: "Henry Wilson",
    joiningDate: "2022-07-08",
    status: "Active",
    email: "noah.garcia@company.com",
    phone: "+1-555-0114",
  },
  {
    id: "15",
    employeeId: "EMP015",
    name: "Olivia White",
    department: "HR",
    role: "Recruitment Specialist",
    reportingManager: "Bob Williams",
    joiningDate: "2023-05-17",
    status: "Active",
    email: "olivia.white@company.com",
    phone: "+1-555-0115",
  },
  {
    id: "16",
    employeeId: "EMP016",
    name: "Paul Clark",
    department: "Engineering",
    role: "Full Stack Developer",
    reportingManager: "Alice Johnson",
    joiningDate: "2023-09-01",
    status: "Active",
    email: "paul.clark@company.com",
    phone: "+1-555-0116",
  },
  {
    id: "17",
    employeeId: "EMP017",
    name: "Quinn Adams",
    department: "Design",
    role: "UI/UX Designer",
    reportingManager: "Leo Brown",
    joiningDate: "2022-08-25",
    status: "Active",
    email: "quinn.adams@company.com",
    phone: "+1-555-0117",
  },
  {
    id: "18",
    employeeId: "EMP018",
    name: "Rachel Hill",
    department: "Data",
    role: "Data Analyst",
    reportingManager: "John Smith",
    joiningDate: "2023-02-14",
    status: "Inactive",
    email: "rachel.hill@company.com",
    phone: "+1-555-0118",
  },
];

const departments = Array.from(new Set(dummyEmployees.map((e) => e.department)));
const statusOptions: EmployeeStatus[] = ["Active", "Inactive", "Probation"];

const ITEMS_PER_PAGE = 10;

// --- Status Badge Component ---
function StatusBadge({ status }: { status: EmployeeStatus }) {
  const styles: Record<EmployeeStatus, string> = {
    Active: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400",
    Inactive: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
    Probation: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400",
  };
  return (
    <span
      className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${styles[status]}`}
    >
      {status}
    </span>
  );
}

// --- Main Component ---
export default function EmployeeList() {
  // State
  const [searchQuery, setSearchQuery] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState<string>("All");
  const [statusFilter, setStatusFilter] = useState<string>("All");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedEmployee, setSelectedEmployee] = useState<string | null>(null);
  const [showActions, setShowActions] = useState<string | null>(null);
  const [showUpload, setShowUpload] = useState(false);

  // Filter logic
  const filteredEmployees = useMemo(() => {
    return dummyEmployees.filter((emp) => {
      const matchesSearch =
        emp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.employeeId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emp.email.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesDepartment =
        departmentFilter === "All" || emp.department === departmentFilter;

      const matchesStatus =
        statusFilter === "All" || emp.status === statusFilter;

      return matchesSearch && matchesDepartment && matchesStatus;
    });
  }, [searchQuery, departmentFilter, statusFilter]);

  // Pagination
  const totalPages = Math.ceil(filteredEmployees.length / ITEMS_PER_PAGE);
  const paginatedEmployees = filteredEmployees.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  // Reset page when filters change
  const handleSearchChange = (val: string) => {
    setSearchQuery(val);
    setCurrentPage(1);
  };
  const handleDeptChange = (val: string) => {
    setDepartmentFilter(val);
    setCurrentPage(1);
  };
  const handleStatusChange = (val: string) => {
    setStatusFilter(val);
    setCurrentPage(1);
  };

  // CSV Export
  const exportToCSV = () => {
    const headers = [
      "Employee ID",
      "Name",
      "Department",
      "Role",
      "Reporting Manager",
      "Joining Date",
      "Status",
      "Email",
      "Phone",
    ];
    const rows = filteredEmployees.map((emp) => [
      emp.employeeId,
      emp.name,
      emp.department,
      emp.role,
      emp.reportingManager,
      emp.joiningDate,
      emp.status,
      emp.email,
      emp.phone,
    ]);
    const csvContent = [headers, ...rows]
      .map((row) => row.map((field) => `"${field}"`).join(","))
      .join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "employees_export.csv");
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[var(--foreground)]">
            Employee Directory
          </h1>
          <p className="text-sm text-[var(--muted)] mt-1">
            Manage all employees across your organization
          </p>
        </div>
        <div className="flex gap-2">
  <button className="flex items-center gap-2 px-4 py-2 bg-[var(--primary)] text-white rounded-lg hover:opacity-90 transition font-medium">
    <Plus size={18} />
    Add Employee
  </button>

  <button
    onClick={() => setShowUpload(!showUpload)}
    className="flex items-center gap-2 px-4 py-2 border border-[var(--border)] rounded-lg hover:bg-[var(--hover)] transition font-medium"
  >
    Bulk Upload
  </button>
</div>
      </div>
      {showUpload && <BulkUpload />}

      {/* Filters & Search Bar */}
      <div className="flex flex-col lg:flex-row gap-4 p-4 bg-[var(--card)] border border-[var(--border)] rounded-xl">
        {/* Search */}
        <div className="flex-1 relative">
          <Search
            size={18}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted)]"
          />
          <input
            type="text"
            placeholder="Search by name, ID, or email..."
            value={searchQuery}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[var(--background)] border border-[var(--border)] rounded-lg text-sm outline-none focus:ring-2 focus:ring-[var(--ring)]"
          />
        </div>

        {/* Department Filter */}
        <div className="relative min-w-[180px]">
          <Filter
            size={18}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted)]"
          />
          <select
            value={departmentFilter}
            onChange={(e) => handleDeptChange(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[var(--background)] border border-[var(--border)] rounded-lg text-sm outline-none appearance-none focus:ring-2 focus:ring-[var(--ring)]"
          >
            <option value="All">All Departments</option>
            {departments.map((dept) => (
              <option key={dept} value={dept}>
                {dept}
              </option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div className="relative min-w-[160px]">
          <Shield
            size={18}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted)]"
          />
          <select
            value={statusFilter}
            onChange={(e) => handleStatusChange(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-[var(--background)] border border-[var(--border)] rounded-lg text-sm outline-none appearance-none focus:ring-2 focus:ring-[var(--ring)]"
          >
            <option value="All">All Statuses</option>
            {statusOptions.map((status) => (
              <option key={status} value={status}>
                {status}
              </option>
            ))}
          </select>
        </div>

        {/* Export Button */}
        <button
          onClick={exportToCSV}
          className="flex items-center gap-2 px-4 py-2 border border-[var(--border)] rounded-lg hover:bg-[var(--hover)] transition"
        >
          <Download size={18} />
          Export CSV
        </button>
      </div>

      {/* Table */}
      <div className="bg-[var(--card)] border border-[var(--border)] rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[var(--border)] bg-[var(--muted)]/50">
                <th className="px-6 py-4 text-left text-xs font-semibold text-[var(--muted-foreground)] uppercase tracking-wider">
                  Employee
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-[var(--muted-foreground)] uppercase tracking-wider">
                  Department
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-[var(--muted-foreground)] uppercase tracking-wider">
                  Role
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-[var(--muted-foreground)] uppercase tracking-wider">
                  Manager
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-[var(--muted-foreground)] uppercase tracking-wider">
                  Joining Date
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-[var(--muted-foreground)] uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-[var(--muted-foreground)] uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {paginatedEmployees.map((employee) => (
                <tr
                  key={employee.id}
                  onClick={() => {}}
                  className="hover:bg-[var(--hover)] cursor-pointer transition group"
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[var(--primary)]/10 flex items-center justify-center text-[var(--primary)]">
                        <User size={20} />
                      </div>
                      <div>
                        <p className="font-medium text-[var(--foreground)]">
                          {employee.name}
                        </p>
                        <p className="text-xs text-[var(--muted)]">
                          {employee.employeeId}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-[var(--foreground)]">
                      <Building2 size={16} className="text-[var(--muted)]" />
                      {employee.department}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-[var(--foreground)]">
                    {employee.role}
                  </td>
                  <td className="px-6 py-4 text-[var(--foreground)]">
                    {employee.reportingManager}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-[var(--foreground)]">
                      <Calendar size={16} className="text-[var(--muted)]" />
                      {employee.joiningDate}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <StatusBadge status={employee.status} />
                  </td>
                  <td className="px-6 py-4 relative">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowActions(showActions === employee.id ? null : employee.id);
                      }}
                      className="p-2 rounded-lg hover:bg-[var(--hover)] transition"
                    >
                      <MoreVertical size={18} className="text-[var(--muted)]" />
                    </button>
                    {showActions === employee.id && (
                      <div className="absolute right-6 top-14 z-10 w-40 bg-[var(--card)] border border-[var(--border)] rounded-lg shadow-lg">
                        <button className="w-full flex items-center gap-2 px-4 py-2 text-sm hover:bg-[var(--hover)] transition">
                          <Edit size={16} />
                          Edit
                        </button>
                        <button className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition">
                          <Trash2 size={16} />
                          Delete
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Empty State */}
        {paginatedEmployees.length === 0 && (
          <div className="p-12 text-center text-[var(--muted)]">
            <User size={48} className="mx-auto mb-3 opacity-50" />
            <p>No employees found matching your criteria.</p>
          </div>
        )}
      </div>

      {/* Pagination */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <p className="text-sm text-[var(--muted)]">
          Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1} to{" "}
          {Math.min(currentPage * ITEMS_PER_PAGE, filteredEmployees.length)} of{" "}
          {filteredEmployees.length} employees
        </p>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-2 rounded-lg border border-[var(--border)] hover:bg-[var(--hover)] disabled:opacity-50 disabled:cursor-not-allowed transition"
          >
            <ChevronLeft size={18} />
          </button>
          <div className="flex items-center gap-1">
            {Array.from({ length: totalPages }, (_, i) => i + 1)
              .filter(
                (page) =>
                  page === 1 ||
                  page === totalPages ||
                  Math.abs(page - currentPage) <= 1
              )
              .map((page, idx, arr) => (
                <span key={page}>
                  {idx > 0 && arr[idx - 1] !== page - 1 && (
                    <span className="px-2 text-[var(--muted)]">...</span>
                  )}
                  <button
                    onClick={() => setCurrentPage(page)}
                    className={`w-10 h-10 rounded-lg text-sm transition ${
                      currentPage === page
                        ? "bg-[var(--primary)] text-white"
                        : "hover:bg-[var(--hover)]"
                    }`}
                  >
                    {page}
                  </button>
                </span>
              ))}
          </div>
          <button
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-2 rounded-lg border border-[var(--border)] hover:bg-[var(--hover)] disabled:opacity-50 disabled:cursor-not-allowed transition"
          >
            <ChevronRight size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
