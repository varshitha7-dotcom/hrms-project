"use client";

import Link from "next/link";
import { useLayout } from "./layout-context";
import { useRouter, usePathname } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/hooks/useAuth";

import {
  UserPlus,
  Users,
  CalendarCheck,
  ClipboardList,
  Clock,
  HelpCircle,
  FileText,
  BarChart3,
  DollarSign,
  Smile,
  PieChart,
  LogOut,
  Building2,
} from "lucide-react";

// 🔥 MENU WITH ROLE CONTROL
const menuItems = [
  { label: "Dashboard", href: "/dashboard", icon: UserPlus, roles: ["super_admin", "admin", "hr"] },

  { label: "Employees", href: "/employees", icon: Users, roles: ["super_admin", "admin", "hr"] },

  { label: "Attendance and Leave", href: "/attendance", icon: CalendarCheck, roles: ["super_admin", "admin", "hr"] },

  { label: "Recruitment", href: "/recruitment", icon: ClipboardList, roles: ["super_admin", "admin", "hr"] },

  { label: "Timesheet and Utilization", href: "/timesheets", icon: Clock, roles: ["super_admin", "admin"] },

  { label: "Payroll Management", href: "/payroll", icon: DollarSign, roles: ["super_admin", "admin"] },

  { label: "Expense Management", href: "/expenses", icon: DollarSign, roles: ["super_admin", "admin"] },

  { label: "Performance Management", href: "/performance", icon: BarChart3, roles: ["super_admin", "admin", "hr"] },

  { label: "Learning and Development", href: "/learning", icon: Smile, roles: ["super_admin", "admin", "hr"] },

  { label: "Asset Management", href: "/asset", icon: FileText, roles: ["super_admin", "admin"] },

  { label: "Reporting and Analytics", href: "/analytics", icon: PieChart, roles: ["super_admin", "admin"] },

  { label: "User and Role Management", href: "/userandrole", icon: Users, roles: ["super_admin"] },

  { label: "Settings and Config", href: "/settings", icon: HelpCircle, roles: ["super_admin"] },
];

export default function Sidebar() {
  const { collapsed } = useLayout();
  const router = useRouter();
  const pathname = usePathname();
  const { profile, loading } = useAuth();

  // 🔥 Logout
  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.replace("/auth/login");
  };

  // 🔥 Prevent render before role loads
  if (loading || !profile) return null;

  // 🔥 Filter menu based on role
  const filteredMenu = menuItems.filter((item) =>
    item.roles.includes(profile.role)
  );

  return (
    <aside
      className={`${
        collapsed ? "w-20" : "w-72"
      } bg-[var(--sidebar)] border-r border-[var(--border)] transition-all duration-300 flex flex-col`}
    >
      {/* LOGO */}
      <div className="h-16 flex items-center px-4 gap-3 border-b border-[var(--border)]">
        <div className="w-10 h-10 flex items-center justify-center rounded-lg bg-[var(--primary)] text-white">
          <Building2 size={20} />
        </div>

        {!collapsed && (
          <div className="flex flex-col leading-tight">
            <span className="font-semibold text-[15px]">HRMS</span>
            <span className="text-xs text-[var(--muted)]">Portal</span>
          </div>
        )}
      </div>

      {/* MENU LABEL */}
      {!collapsed && (
        <div className="px-6 mt-4 text-xs text-[var(--muted)]">
          MENU
        </div>
      )}

      {/* MENU ITEMS */}
      <nav className="flex-1 px-3 mt-2 space-y-1">
        {filteredMenu.map((item, index) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;

          return (
            <Link key={index} href={item.href}>
              <div
                className={`flex items-center gap-3 px-4 py-3 rounded-lg cursor-pointer transition
                ${
                  isActive
                    ? "bg-[var(--primary)] text-white"
                    : "text-[var(--sidebar-text)] hover:bg-[var(--hover)]"
                }`}
              >
                <Icon
                  size={18}
                  className={isActive ? "text-white" : "text-[var(--muted)]"}
                />

                {!collapsed && (
                  <span className="text-[15px] font-medium">
                    {item.label}
                  </span>
                )}
              </div>
            </Link>
          );
        })}
      </nav>

      {/* LOGOUT */}
      <div className="mt-auto p-3 border-t border-[var(--border)]">
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-4 py-3 w-full rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition"
        >
          <LogOut size={18} />
          {!collapsed && <span>Logout</span>}
        </button>
      </div>
    </aside>
  );
}