import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: "var(--primary)",
        border: "var(--border)",
        muted: "var(--muted)",
        sidebar: "var(--sidebar)",
      },
    },
  },
  plugins: [],
};

export default config;